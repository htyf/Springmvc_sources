package cn.itcast.ssm.controller.validation;

/**
 * 
 * <p>Title: ValidGroup1</p>
 * <p>Description:校验分组，用于商品修改的校验 </p>
 * <p>Company: www.itcast.com</p> 
 * @author	传智.燕青
 * @date	2015-3-22下午2:35:34
 * @version 1.0
 */
public interface ValidGroup1 {
	//接口不定义方法，就是只标识 哪些校验 规则属于该 ValidGroup1分组
}
